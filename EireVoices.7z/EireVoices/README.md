# EireVoices
A simple app to reproduce text with different voices
