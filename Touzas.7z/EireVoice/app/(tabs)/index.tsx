import { StyleSheet } from 'react-native';

import EditScreenInfo from '@/components/EditScreenInfo';
import { Text, View } from '@/components/Themed';
import ResponsiveKeyboardScreen from '@/components/ResponsiveKeyboard';
import Colors from '@/constants/Colors';

export default function TabOneScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Escribe lo que quieras decir || Write what you want to say </Text>
      <View style={styles.separator} lightColor="#eee" darkColor="rgba(255,255,255,0.1)" />
      <ResponsiveKeyboardScreen />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    color: Colors.PinkTheme.Purple
  },
  separator: {
    marginVertical: 30,
    height: 1,
    width: '90%',
  },
});
