import type { Theme } from '@react-navigation/native/src/types';
import { fonts } from '@react-navigation/native/src/theming/fonts';

export const Eiretheme : ReactNavigation.Theme = {
  dark: false,
  colors: {
    primary: 'purple',
    background: '#ffc0cb',
    card: 'purple',
    text: 'white',
    border: 'purple',
    notification: 'purple',
  },
  fonts,
};

export const EirethemeDark : ReactNavigation.Theme = {
    dark: true,
    colors: {
      background: "#010101", 
      border: "#272729", 
      card: "#121212",
      notification: "#ff453a", 
      primary: "#0a84ff", 
      text: "#e5e5e7", 
    },
    fonts,
};