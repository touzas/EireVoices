import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput } from 'react-native';
import Animated, { useSharedValue, useAnimatedStyle, withTiming } from 'react-native-reanimated';
import { Pressable, Dimensions, Alert } from 'react-native';
import Colors from '@/constants/Colors';
import * as Speech from 'expo-speech';
import SpainFlag from '@/assets/images/SpainFlag';
import UkFlag from '@/assets/images/UkFlag';

const ResponsiveKeyboardScreen: React.FC = () => {
    const [inputValue, setInputValue] = useState<string>('');
    const [isSpeaking, setIsSpeaking] = React.useState(false);
    const [isUppercase, SetUppercase] = React.useState(true);
    const [isPortrait, setOrientation] = React.useState(
        Dimensions.get('window').height > Dimensions.get('window').width
          ? true
          : false
    );
    const handleLayoutChange = () => {
        const { height, width } = Dimensions.get('window');
        setOrientation(height > width ? true : false);
    };

    const handleKeyPress = (key: string) => {
        setInputValue((prev) => prev + (isUppercase ? key.toLocaleUpperCase() : key.toLocaleLowerCase() ) );
    };

    const handleDelete = () => {
        setInputValue((prev) => prev.slice(0, -1));
    };

    const handleClear = () => {
        setInputValue('');
    };

    const handleUppercase = () => {
        SetUppercase(!isUppercase);
    }

    const playAudio = async (language: string) => {
        let options = {
          language: language,
          pitch: 1.5,
          rate: 1
        };
        console.log(language);
        if (isSpeaking) 
          return;

        setIsSpeaking(true);
        await Speech.speak(inputValue, options);
        setIsSpeaking(false);
    };

    const confirmDeleteAll = () => {
        Alert.alert('Estás segur@?', '¿Quieres borrar todo el texto?', [
          {
            text: 'Cancel',
            onPress: () => console.log('Cancel Pressed'),
            style: 'cancel',
          },
          {text: 'OK', onPress: () => handleClear() },
        ]);
    }

    const renderKeyboard = () => {
        const keys = [
            ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '⌫'],
            ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'],
            ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'Ñ'],
            ['⇑', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', ',', '.'],
            ['Espacio', 'Borrar'],
        ];

        return keys.map((row, rowIndex) => (
            <View key={rowIndex} style={styles.keyboardRow}>
                {
                    row.map((key) => {
                        const scale = useSharedValue(1);
                        const isSpecialKey = (
                            key === 'Espacio' || 
                            key === '⌫' || 
                            key == 'Borrar' ||
                            key === '⇑');

                        const animatedStyle = useAnimatedStyle(() => {
                            return {
                                transform: [{ scale: scale.value }],
                            };
                        });

                        const onPressIn = () => {
                            scale.value = withTiming(0.9, { duration: 50 });
                        };

                        const onPressOut = () => {
                            scale.value = withTiming(1, { duration: 50 });
                        };

                        const getStyle = (key: string) => {
                            if (key === 'Espacio') 
                                return styles.spaceKey;
                            else if (key === '⌫')
                                return styles.clearKey;
                            else if (key === '⇑')
                                return styles.uppercaseKey;
                            else if (key === 'Borrar')
                                return styles.deleteKey;
                            return null;
                        }

                        return (
                            <Pressable
                                key={key}
                                onPressIn={onPressIn}
                                onPressOut={() => {
                                    onPressOut();
                                    if (key === '⌫') handleDelete();
                                    else if (key === 'Borrar') confirmDeleteAll();
                                    else if (key === 'Espacio') handleKeyPress(' ');
                                    else if (key === '⇑') handleUppercase();
                                    else handleKeyPress(key);
                                }}
                            >
                                <Animated.View style={
                                    [styles.key, getStyle(key), null, //{width: isPortrait ? 45 : 65 }, 
                                        animatedStyle]
                                    }>
                                    <Text style={ [isSpecialKey && key !== '⇑' ? styles.keyTextWhite : styles.keyText, null, animatedStyle] }>
                                        { !isUppercase && !isSpecialKey ? key.toLocaleLowerCase() : key.toLocaleUpperCase() }
                                    </Text>
                                </Animated.View>
                            </Pressable>
                        );
                    })
                }
            </View>
        ));
    };

  return (
    <View style={styles.container}>
        <TextInput
            style={styles.input}
            value={inputValue}
            placeholder="Escribe lo que quieras decir..."
            editable={false} // Disable focus
            showSoftInputOnFocus={false} // Disable native keyboard
            multiline={true}
            onLayout={handleLayoutChange}
            numberOfLines={isPortrait ? 7 : 3 }
        />
        <View style={styles.keyboardContainer}>{renderKeyboard()}</View>
        <View style={styles.playButtons}>    
            <Pressable
                key={'playES'}
                onPressOut={() => playAudio('es-ES')}
            >
                <Animated.View style={ styles.buttonPlay}>
                    <SpainFlag width={24} height={24} style={{marginRight: 5}} />
                    <Text style={styles.buttonPlayText}>Castellano</Text>
                </Animated.View>
            </Pressable>
            <Pressable
                key={'playEN'}
                onPressOut={() => playAudio('en-US')}
            >
                <Animated.View style={styles.buttonPlay}>
                    <UkFlag width={24} height={24} style={{marginRight: 5}} />
                    <Text style={styles.buttonPlayText}>English</Text>
                </Animated.View>
            </Pressable>
        </View>
    </View>
  );
};

export default ResponsiveKeyboardScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        padding: 20,
        width: '99%'
    },
    input: {
        borderColor: 'purple',
        borderWidth: 1,
        borderRadius: 8,
        paddingHorizontal: 10,
        fontSize: 18,
        marginBottom: 30,
        backgroundColor: '#fff',
        flex: 1,
        textAlignVertical: 'top'
    },
    keyboardContainer: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    keyboardRow: {
        flexDirection: 'row',
        marginBottom: 10,
    },
    key: {
        width: 60,
        height: 40,
        backgroundColor: '#eaeaea',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 8,
        marginHorizontal: 5,
        fontWeight: 'bold',
    },
    spaceKey: {
        width: 400, // Wider key for Space
        backgroundColor: Colors.PinkTheme.Purple,
        color: Colors.PinkTheme.Pink,
    },
    keyText: {
        fontSize: 18,
        color: 'purple',
    },
    keyTextWhite: {
        fontSize: 18,
        color: 'white',
    },
    clearKey: {
        width: 100, // Wider key for Space
        backgroundColor: Colors.PinkTheme.Purple,
        color: Colors.PinkTheme.Pink,
    },
    deleteKey: {
        width: 100, // Wider key for Space
        backgroundColor: Colors.PinkTheme.Purple,
        color: Colors.PinkTheme.Pink,
    },
    uppercaseKey: {
        minWidth: 50,
        fontSize: 30,
        fontWeight: 'bold',
        color: Colors.PinkTheme.Pink,
    },
    playButtons:{
        flex: 1,
        flexDirection:'row',
        alignItems: 'center',
        justifyContent: 'center',
    },
    buttonPlay: {
        flexDirection: 'row',
        color: 'red',
        backgroundColor: Colors.PinkTheme.Purple,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 5,
        borderRadius: 5,
        margin: 1.5,
        borderColor: Colors.PinkTheme.Purple,
        borderWidth: 2
    },
    buttonPlayText: {
        color: 'white',
        fontSize: 20,
        minWidth: 200,
        textAlign: 'center'
    }
});
