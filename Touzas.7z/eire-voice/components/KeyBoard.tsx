import { BasicKeys as Keys } from '@/constants/Keys';
import { Button, Text, View } from './Themed';
import { StyleSheet, TouchableOpacity } from 'react-native';
import { AntDesign } from '@expo/vector-icons';
import React from 'react';

interface ButtonProps {
  icon: string | undefined;
  buttonKey: string;
  text: string;
  onClick: (text: string) => void;
  isUppercase?: boolean;
}

const CustomButton: React.FC<ButtonProps> = ({ icon, buttonKey, text, onClick, isUppercase }) => {
  const defaultIconSize: number = 32;
  switch(icon){
    case 'BackSpace':
      return <AntDesign name="arrowleft" size={defaultIconSize} color="white" key={buttonKey} style={ styles.backspace } onPress={ () => onClick(text) } />;
    case 'CapsLock':
      if (!isUppercase)
        return <Text key={buttonKey} onPress={ () => onClick(text) } style={ styles.uppercase }>Mayúsculas</Text>;
      else
        return <Text key={buttonKey} onPress={ () => onClick(text) } style={ styles.uppercase }>Minúsculas</Text>;
    case 'Clear':
      return <AntDesign name="closecircleo" size={defaultIconSize} color="white" key={buttonKey} style={ styles.clear } onPress={ () => onClick(text) } />;
    default:
      return <Text key={buttonKey} onPress={ () => onClick(text) } style={ styles.key }>{text}</Text>;
  }
};

export type KeyboardProps = {
  onClick: (key:string) => void; 
  children?: React.ReactNode; 
  isUppercase: boolean;
};

export const Keyboard = ({ onClick, isUppercase } : KeyboardProps) => {
  const [components, setComponents] = React.useState<JSX.Element[]>([]);
  
  React.useEffect(() => {
    const tempComponents: JSX.Element[] = [];

    for (let i=1; i<=5; i++){
      const keysByFile = Keys.filter((k) => k.line == i);
      //<View style={styles.keyRow}>{renderKeysByFile(1)}</View>
      // Componentes dentro de componentes?
      keysByFile.map(item => {
        const text: string = (isUppercase) ? item.value.toLocaleUpperCase() : item.value.toLocaleLowerCase();
        const buttonKey: string = `Key_${item.line}_${i}`;
  
        tempComponents.push(
          <CustomButton
            icon={item.specialKey}
            buttonKey={buttonKey}
            text= {text}
            onClick={ () => onClick(text) }
            isUppercase = {isUppercase}
          />
        );
      });
    }
    setComponents(tempComponents);
  }, []);

  return (
    <View style={styles.keyboardContainer}>
      {components}
    </View>
  );
};

  const styles = StyleSheet.create({
    keyboardContainer: {
      flex: 1,
      backgroundColor: '#ffc0cb',
      marginTop: 5,
      padding: 3,
    },
    keyRow: {
      flexDirection: 'row',
      marginBottom: 5,
      backgroundColor: '#ffc0cb',
    },
    key: {
      flex: 1,
      backgroundColor: '#ffc0cb',
      justifyContent: 'center',
      alignItems: 'center',
      borderRadius: 5,
      margin: 3,
      padding: 5,
      borderWidth: 2,
      textAlign: 'center',
      fontWeight: 'bold',
      color: 'black',
      fontSize: 20
    },
    backspace: {
      flex: 3,
      backgroundColor: 'purple',
      borderRadius: 5,
      margin: 3,
      padding: 5,
      borderWidth: 2,
      textAlign: 'center'
    },
    uppercase: {
      flex: 2,
      backgroundColor: 'purple',
      color: 'white',
      borderRadius: 5,
      margin: 3,
      padding: 5,
      borderWidth: 2,
      textAlign: 'center',
      fontWeight: 'bold',
      fontSize: 20
    },
    clear: {
      flex: 2,
      backgroundColor: 'purple',
    },
    space: {
      alignSelf: 'stretch',
      flex: 10,
    },
    textWhite: {
      color: 'white',
    },
  });