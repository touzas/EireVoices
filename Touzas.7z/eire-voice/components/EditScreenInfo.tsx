import React from 'react';
import { Dimensions, StyleSheet, TextInput, TouchableOpacity } from 'react-native';
import * as Speech from 'expo-speech';
import { Text, View } from './Themed';
import { Keyboard } from './KeyBoard';
import SpainFlag from '../assets/SpainFlag';
import UKFlag from '../assets/UKFlag';

export default function EditScreenInfo({ path }: { path: string }) {
  const [text, SetText] = React.useState('');
  const [isUppercase, SetUppercase] = React.useState(true);
  const [isSpeaking, setIsSpeaking] = React.useState(false);
  const [isPortrait, setOrientation] = React.useState(
    Dimensions.get('window').height > Dimensions.get('window').width
      ? true
      : false
  );

  const handleLayoutChange = () => {
    const { height, width } = Dimensions.get('window');
    setOrientation(height > width ? true : false);
  };

  const writeText = (val: string) => {
    const textValue = val.toLocaleLowerCase();

    if (textValue == '<<'){
      SetText(text.slice(0, -1));
    }
    else if (textValue === 'mayúsculas' || textValue === 'may'){
      SetUppercase(!isUppercase);
    }
    else if (textValue == 'clear'){
      SetText('');
    }
    else{
      const keyPressed = (isUppercase) ? val.toLocaleUpperCase() : val.toLocaleLowerCase();
      SetText(text + keyPressed);
    }
  }

  const playAudio = async (language: string) => {
    let options = {
      language: language,
      pitch: 1.5,
      rate: 1
    };
    if (isSpeaking) 
      return;
    setIsSpeaking(true);
    
    await Speech.speak(text, options);
    setIsSpeaking(false);
  };

  return (
    <View style={{flex: 1, flexDirection: 'row', backgroundColor: '#ffc0cb'}}>
      <View style={{flex: 2, backgroundColor: '#ffc0cb'}}>
      <TextInput 
          multiline={true}
          underlineColorAndroid='transparent'
          onLayout={handleLayoutChange}
          style={!isPortrait ? styles.inputContainer : styles.inputContainerLandScape}
          placeholder='Escribe lo que quieras decir'
          placeholderTextColor="gray"         
          numberOfLines={isPortrait ? 8 : 3 }
          value={text}
          showSoftInputOnFocus={false}
        />
        <View style={styles.keyboard}>
          <Keyboard onClick={  writeText } isUppercase={isUppercase} isPortrait={isPortrait} />
        </View>
        <View style={styles.buttons}>
          <TouchableOpacity 
            style={styles.buttonPlay}
            onPress={() => playAudio('es-ES')}
          >
            <SpainFlag width={18} height={18} style={{marginRight: 5}} />
            <Text style={{color: 'white'}}>Castellano</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.buttonPlay}
            onPress={() => playAudio('en-US')}
          >
            <UKFlag width={18} height={18} style={{marginRight: 5}} />
            <Text style={{color: 'white'}}>English</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    paddingTop: 5,
    flexDirection: 'row',
  },
  inputContainer: {
    borderRadius: 10,
    backgroundColor: "white",
    borderWidth: 1,
    borderColor: "gray",
    padding: 5,
    fontSize: 50,
    marginRight: 10,
    marginLeft: 10,
  },
  inputContainerLandScape: {
    borderRadius: 5,
    backgroundColor: "transparent",
    borderWidth: 1,
    borderColor: "gray",
    padding: 3,
    fontSize: 30,
    margin:1
  },
  keyboard: {
    flex:6,
    margin: 1,
  },
  buttons:{
    flex: 1,
    flexDirection:'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#ffc0cb'
  },
  buttonPlay: {
    flex: 1,
    flexDirection: 'row',
    color: 'white',
    backgroundColor: 'gray',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 5,
    margin: 1.5,
    padding: 10,
    borderColor: 'black',
    borderWidth: 2
  },
});
